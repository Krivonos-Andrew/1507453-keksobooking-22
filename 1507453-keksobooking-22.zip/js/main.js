'use strict';

function getRandomFloat(min, max) {
  if (min === max) {
    return 0;
  }
  const minValue = Math.min(min, max);
  const maxValue = Math.max(min, max);
  return Math.random() * (maxValue - minValue) + minValue;
}
// eslint-disable-next-line no-console
console.log(getRandomFloat(1, 10));

function getRandomInRange(min, max) {
  if (min === max) {
    return 0;
  }
  const minValue = Math.min(min, max);
  const maxValue = Math.max(min, max);
  return Math.floor(Math.random() * (maxValue - minValue + 1)) + minValue;
}
// eslint-disable-next-line no-console
console.log(getRandomInRange(1, 10));


const autor {
  avatar: 'img/avatars/user{{xx}}.png';
}

const offer {
  title: 'Мое объявление';
  adress: {
    {
      location.x
    }
  },
  {
    {
      location.y
    }
  };
  price: const cost = getRandomFloat(1, 10);
  type: 'palace',
  'flat',
  'house',
  'bungalow';
  rooms: const cost = getRandomFloat(1, 10);
  guests: const cost = getRandomFloat(1, 10);
  checkin: '12:00',
  '13:00',
  '14:00';
  let features = [wifi, dishwasher, parking, washer, elevator, conditioner];
  const createArrFeatures = ([...source], maxLength) => Array.from({
      length: Math.min(source.length, 1 + Math.random() * maxLength | 0)
    },
    () => source.splice(Math.random() * source.length | 0, 1)[0]
  );
  description: 'Описание помещения';
  photos = ['http: //o0.github.io/assets/images/tokyo/hotel1.jpg', 'http://o0.github.io/assets/images/tokyo/hotel2.jpg', 'http://o0.github.io/assets/images/tokyo/hotel3.jpg'];
}

const location {
  x: getRandomInRange(35.65000, 35.70000);
  y: getRandomInRange(139.70000, 139.80000);
}
